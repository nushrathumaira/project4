#include "types.h"
#include "stat.h"
#include "user.h"


int main(int argc, char *argv[])
{
  printf(1,"Test for null pointer dereference.\n");
  int c;
  int *pi = NULL;
  c = *pi;
  printf(1,"Dereferencing a null pointer: %d.\n",c);
  exit();

}

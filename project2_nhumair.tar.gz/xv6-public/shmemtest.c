#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"


int main(int argc, char *argv[])
{

  int* p =(int*) shmem_access(0);
  *p = 100;
  printf(1,"test access shared page 0: write a value and read it.\n");
  printf(1,"Address 0x%x, value %d\n",p,*p);
  int* q =(int*) shmem_access(1);
  *q = 200;
  printf(1,"test access shared page 1: write a value and read it.\n");
  printf(1,"Address 0x %x, value %d\n",q,*q);
  int* r =(int*) shmem_access(2);
  *r = 300;
  printf(1,"test access shared page 2: write a value and read it.\n");
  printf(1,"Address 0x%x, value %d\n",r,*r);
  int* s =(int*) shmem_access(3);
  *s = 400;
  printf(1,"test access shared page 3: write a value and read it.\n");
  printf(1,"Address 0x%x, value %d\n",s,*s);
  int* t =(int*) shmem_access(1);
  *t = 500;
  printf(1,"test access shared page 1 again: change the value and read it.\n");
  printf(1,"Address 0x%x, value %d\n",t,*t);
  int* u =(int*) shmem_access(4);
  printf(1,"test access invalid shared page 4.\n");
  printf(1,"Address 0x%x\n",u);

  int i;





  printf(1,"test count for each valid page how many process currently access it(before fork).\n");
  for(i = 0 ; i < 4 ; i++)
  {
    printf(1,"%d ",shmem_count(i));
  }
  printf(1,"\n");

  int pid = fork();
  if(pid > 0)
  {//parent
    wait();
    printf(1,"back from child process.\n");
    printf(1,"Address 0x %x, value %d (expected = 45 changed by child)\n",q,*q);
    printf(1,"test count for each valid page how many process currently access it.\n");
    for(i = 0 ; i < 4 ; i++)
    {
      printf(1,"%d ",shmem_count(i));
    }
    printf(1,"\n");

  }
  else if(pid == 0){
    printf(1,"child process starts.\n");
    *q = 45;
    printf(1,"test access shared pages from parents\n");
    printf(1,"Address of p 0x%x, value %d\n",p,*p);
    printf(1,"test count for each valid page how many process currently access it.\n");
    for(i = 0 ; i < 4 ; i++)
    {
      printf(1,"%d ",shmem_count(i));
    }
    printf(1,"\n");
    char *myargv[2];
    myargv[0] = "shmemexectest";
    myargv[1] = 0;
    exec("shmemexectest",myargv);
    exit();
  }
  exit();
}

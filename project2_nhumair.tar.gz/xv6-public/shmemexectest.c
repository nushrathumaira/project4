#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"



int main(int argc, char *argv[])
{

  printf(1,"called by exec\n");
  int *p = shmem_access((int)argv[1]);
  printf(1,"address %x and  value of shared page 0 is %d\n",p,*p);
  printf(1,"shmem count after exec %d\n",shmem_count((int)argv[1]));
  exit();
}

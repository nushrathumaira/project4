#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  int pid = getpid();

  if(fork() == 0)
  {

    uint* nullPointer = (uint*)0;
    printf(1,"Dereferencing a null pointer: %x\n", *nullPointer);
    //kill the process
    kill(pid);
    exit();
  }
  else
  {
    wait();
  }

  exit();


}
